package models

type Tugas struct {
	ID          uint
	Judul       string
	Deskripsi   string
	MahasiswaID uint
	Hasil       Hasil
}
