package models

type Hasil struct {
	ID      uint
	TugasID uint
	Nilai   int
}
